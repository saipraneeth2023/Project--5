const DEFAULT_SERVER_URL = 'https://hackmd.io'

module.exports = {
  DEFAULT_SERVER_URL
}
